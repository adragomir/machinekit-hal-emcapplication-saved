#!/usr/bin/python
import sys
import os
import subprocess
from time import sleep
from machinekit.hal.launcher import launcher

os.chdir(os.path.dirname(os.path.realpath(__file__)))

launcher.set_debug_level(0)

try:
    launcher.check_installation()
    launcher.cleanup_session()
    # Uncomment and modify the following line of you have custom HAL components
    # launcher.install_comp('gantry.comp')  # install a comp HAL component if not already installed
    launcher.start_process('linuxcnc remote29.ini')  # start linuxcnc
    launcher.register_exit_handler()
except subprocess.CalledProcessError:
    launcher.end_session()
    sys.exit(1)

# loop until script receives exit signal
# or one of the started applications exited incorrectly
# cleanup is done automatically
while True:
    sleep(1)
    launcher.check_processes()
