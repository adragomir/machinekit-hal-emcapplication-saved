#!/usr/bin/python
import sys
import os
import subprocess
from time import sleep
from machinekit import launcher
from machinekit import config

os.chdir(os.path.dirname(os.path.realpath(__file__)))

if 'MACHINEKIT_INI' not in os.environ:  # export for package installs
    mkconfig = config.Config()
    os.environ['MACHINEKIT_INI'] = mkconfig.MACHINEKIT_INI
if 'HAL_RTMOD_DIR' not in os.environ:  # export for package installs
    os.environ['HAL_RTMOD_DIR'] = '/usr/lib/linuxcnc'

launcher.set_debug_level(0)

try:
    launcher.check_installation()
    launcher.cleanup_session()
    # Uncomment and modify the following line of you have custom HAL components
    # launcher.install_comp('gantry.comp')  # install a comp HAL component if not already installed
    launcher.start_process('machinekit remote.ini')  # start linuxcnc
    launcher.register_exit_handler()
except subprocess.CalledProcessError:
    launcher.end_session()
    sys.exit(1)

# loop until script receives exit signal
# or one of the started applications exited incorrectly
# cleanup is done automatically
while True:
    sleep(1)
    launcher.check_processes()
