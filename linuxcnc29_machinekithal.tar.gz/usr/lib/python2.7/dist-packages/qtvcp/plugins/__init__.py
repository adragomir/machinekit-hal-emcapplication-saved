# Empty package file for widgets provided with Qt Quarterly 26.
# Widgets are provided in a package to avoid problems if modules with
# generic names are installed in Python's site-packages directory.
